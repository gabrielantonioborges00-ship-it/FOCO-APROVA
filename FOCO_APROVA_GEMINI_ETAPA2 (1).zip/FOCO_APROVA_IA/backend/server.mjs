import http from 'node:http';
import { GoogleGenAI } from '@google/genai';

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const MAX_BODY = 24 * 1024;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || '';
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  : null;

const tutorInstructions = `Você é a Professora IA do FOCO APROVA, uma tutora brasileira especialista em ensinar para concursos de qualquer área: militares, policiais, ENEM, vestibulares e concursos civis.
Ensine em português brasileiro, com clareza, paciência e rigor. Adapte a profundidade ao nível informado.
Quando o aluno estiver começando do zero: explique pré-requisitos, defina termos, use analogias simples e avance em etapas curtas.
Sempre que adequado, organize a aula em: objetivo; explicação; exemplo resolvido passo a passo; erros comuns; resumo para memorizar; exercício para o aluno tentar.
Em matemática e raciocínio, mostre cálculos e justifique cada etapa. Em questões, não revele a resposta antes de dar oportunidade para o aluno tentar, a menos que ele peça a resolução.
Adapte exemplos e dificuldade ao concurso informado, mas nunca invente que uma questão é oficial. Diferencie claramente questões autorais de questões oficiais. Se não souber um dado de edital ou norma atual, avise que precisa ser conferido na fonte oficial.
Se o aluno enviar uma resposta, corrija com respeito, explique o raciocínio e identifique a lacuna de aprendizagem. Não prometa aprovação nem resultados garantidos.`;

function send(res, status, data) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(data));
}

function setCors(req, res) {
  const origin = req.headers.origin;
  if (FRONTEND_ORIGIN && origin === FRONTEND_ORIGIN) {
    res.setHeader('Access-Control-Allow-Origin', FRONTEND_ORIGIN);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

const server = http.createServer(async (req, res) => {
  setCors(req, res);
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  if (req.method === 'GET' && req.url === '/api/ai/health') {
    return send(res, 200, { ready: Boolean(ai), provider: 'Google Gemini', model: ai ? MODEL : null });
  }
  if (req.method !== 'POST' || req.url !== '/api/ai/tutor') {
    return send(res, 404, { error: 'Rota não encontrada.' });
  }
  if (!ai) return send(res, 503, { error: 'Servidor online, mas GEMINI_API_KEY ainda não foi configurada.' });

  try {
    let raw = '';
    for await (const chunk of req) {
      raw += chunk;
      if (Buffer.byteLength(raw) > MAX_BODY) return send(res, 413, { error: 'Mensagem muito grande. Reduza o texto e tente novamente.' });
    }
    const body = JSON.parse(raw || '{}');
    const question = String(body.question || '').trim();
    if (!question) return send(res, 400, { error: 'Escreva sua dúvida antes de enviar.' });
    if (question.length > 8000) return send(res, 413, { error: 'A pergunta deve ter até 8.000 caracteres.' });

    const context = [
      `Concurso/objetivo: ${String(body.exam || 'Não informado').slice(0, 160)}`,
      `Matéria: ${String(body.subject || 'Não informada').slice(0, 120)}`,
      `Nível: ${String(body.level || 'Do absoluto zero').slice(0, 80)}`,
      `Modo de aprendizagem: ${String(body.style || 'Ensinar do zero').slice(0, 100)}`
    ].join('\n');

    const history = Array.isArray(body.history) ? body.history.slice(-12).map(m => ({
      role: m?.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m?.content || '').slice(0, 5000) }]
    })) : [];

    const response = await ai.models.generateContent({
      model: MODEL,
      contents: [...history, { role: 'user', parts: [{ text: question }] }],
      config: {
        systemInstruction: `${tutorInstructions}\n\nCONTEXTO DO ALUNO:\n${context}`,
        maxOutputTokens: 1400,
        temperature: 0.7
      }
    });
    const answer = String(response.text || '').trim();
    if (!answer) return send(res, 502, { error: 'A IA não retornou texto. Tente novamente.' });
    return send(res, 200, { answer, model: MODEL, provider: 'Google Gemini' });
  } catch (error) {
    console.error('Erro na rota /api/ai/tutor:', error?.message || error);
    const status = Number(error?.status) || 500;
    if (status === 429) return send(res, 429, { error: 'O limite gratuito de uso do Gemini foi atingido temporariamente. Aguarde um pouco e tente novamente.' });
    if (status === 400 || status === 403) return send(res, status, { error: 'O Gemini recusou a solicitação. Confira a chave, o modelo e os limites do projeto no Google AI Studio.' });
    return send(res, 500, { error: 'Ocorreu um erro ao gerar a aula. Tente novamente.' });
  }
});

server.listen(PORT, HOST, () => console.log(`FOCO APROVA IA com Gemini ativo em ${HOST}:${PORT} (modelo: ${MODEL})`));
